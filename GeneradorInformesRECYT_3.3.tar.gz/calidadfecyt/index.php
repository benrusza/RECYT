<?php

require_once('CalidadFECYTPlugin.inc.php');

return new CalidadFECYTPlugin();


