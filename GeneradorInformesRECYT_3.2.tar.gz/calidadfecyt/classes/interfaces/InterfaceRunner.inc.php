<?php

namespace CalidadFECYT\classes\interfaces;

interface InterfaceRunner
{
    public function run(&$params);
}